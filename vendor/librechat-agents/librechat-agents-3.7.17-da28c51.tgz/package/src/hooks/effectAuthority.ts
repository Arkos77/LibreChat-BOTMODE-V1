import type { ProgrammaticHookContext } from '@/types';
import type { PreToolUseHookInput } from './types';
import { executeHooks } from './executeHooks';

/** Invoke the native durable phase; this adapter owns no authorization policy. */
export async function revalidateToolEffect(
  required: boolean,
  context: ProgrammaticHookContext | undefined,
  call: Pick<
    PreToolUseHookInput,
    'toolName' | 'toolUseId' | 'toolInput' | 'stepId' | 'turn'
  >
): Promise<Record<string, unknown>> {
  if (!required) return call.toolInput;
  if (context == null) throw new Error('EFFECT_TIME_AUTHORITY_REQUIRED');
  const result = await executeHooks({
    phase: 'effect-time',
    authorityRequired: true,
    registry: context.registry,
    input: {
      hook_event_name: 'PreToolUse',
      runId: context.runId,
      threadId: context.threadId,
      agentId: context.agentId,
      executingAgentId: context.executingAgentId,
      ...call,
    },
    sessionId: context.runId,
    matchQuery: call.toolName,
  });
  if (result.decision !== 'allow') {
    throw new Error(result.reason ?? 'EFFECT_TIME_AUTHORITY_REQUIRED');
  }
  return result.updatedInput ?? call.toolInput;
}
