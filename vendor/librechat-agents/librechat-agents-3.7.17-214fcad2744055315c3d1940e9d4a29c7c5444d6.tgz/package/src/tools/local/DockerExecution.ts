import { spawn } from 'node:child_process';
import type {
  ChildProcessWithoutNullStreams,
  SpawnOptions,
} from 'node:child_process';
import type { ExecutionGrant } from '@/hooks/effectAuthority';
import type * as t from '@/types';

export const DOCKER_NETWORK_MODES = [
  'NONE',
  'LOCAL_LAB',
  'ALLOWLIST',
  'WEB',
  'TOR_ALLOWLIST',
] as const;
export type DockerNetworkMode = (typeof DOCKER_NETWORK_MODES)[number];

export type DockerExecutionConfig = {
  image: string;
  workspaceRoot?: string;
  cpuCores?: number;
  memoryBytes?: number;
  diskBytes?: number;
  networkMode?: DockerNetworkMode;
  allowedDomains?: readonly string[];
  readonlyRoot?: boolean;
  extraEnv?: Record<string, string>;
  user?: string;
  localLabNetwork?: string;
};

export type DockerExecutionCapabilities = {
  cpu: true;
  memory: true;
  ephemeralDisk: true;
  networkModes: readonly DockerNetworkMode[];
};

const defaultLocalLabNetwork = 'librechat_devcontainer_default';

function dockerNetworkFor(
  config: DockerExecutionConfig,
  mode: DockerNetworkMode
): string {
  if (mode === 'LOCAL_LAB')
    return (
      config.localLabNetwork ||
      process.env.BOTMODE_DOCKER_LOCAL_NETWORK ||
      defaultLocalLabNetwork
    );
  if (mode === 'WEB') return 'bridge';
  return 'none';
}

function assertFinitePositive(name: string, value: number | undefined): void {
  if (value != null && (!Number.isFinite(value) || value <= 0)) {
    throw new Error(`Docker ${name} must be a positive finite number.`);
  }
}

export function validateDockerExecutionConfig(
  config: DockerExecutionConfig
): void {
  if (!config.image?.trim()) throw new Error('Docker image is required.');
  assertFinitePositive('cpuCores', config.cpuCores);
  assertFinitePositive('memoryBytes', config.memoryBytes);
  assertFinitePositive('diskBytes', config.diskBytes);
  const mode = config.networkMode ?? 'NONE';
  if (!DOCKER_NETWORK_MODES.includes(mode))
    throw new Error(`Unsupported Docker network mode: ${mode}`);
  if (
    (mode === 'ALLOWLIST' || mode === 'TOR_ALLOWLIST') &&
    (config.allowedDomains?.length ?? 0) === 0
  ) {
    throw new Error(`${mode} requires at least one allowed domain.`);
  }
  if (mode === 'NONE' && (config.allowedDomains?.length ?? 0) > 0) {
    throw new Error('NONE network mode cannot carry allowed domains.');
  }
}

export function buildDockerArgs(
  config: DockerExecutionConfig,
  command: string,
  args: string[]
): string[] {
  validateDockerExecutionConfig(config);
  const mode = config.networkMode ?? 'NONE';
  if (mode === 'ALLOWLIST' || mode === 'TOR_ALLOWLIST') {
    throw new Error(
      `Docker backend cannot enforce ${mode} domain filtering without a policy-aware proxy.`
    );
  }
  const argv = [
    'run',
    '--rm',
    '--init',
    '--name',
    `lc-botmode-${process.pid}-${Date.now()}`,
  ];
  if (config.cpuCores != null) argv.push('--cpus', String(config.cpuCores));
  if (config.memoryBytes != null) {
    argv.push(
      '--memory',
      String(config.memoryBytes),
      '--memory-swap',
      String(config.memoryBytes)
    );
  }
  if (config.diskBytes != null)
    argv.push('--tmpfs', `/tmp:rw,nosuid,nodev,size=${config.diskBytes}`);
  argv.push('--network', dockerNetworkFor(config, mode));
  if (config.user) argv.push('--user', config.user);
  if (config.readonlyRoot === true) argv.push('--read-only');
  const workspace = config.workspaceRoot;
  if (workspace) {
    argv.push(
      '--mount',
      `type=bind,src=${workspace},dst=/workspace${config.readonlyRoot ? ',readonly' : ''}`,
      '--workdir',
      '/workspace'
    );
  }
  for (const [key, value] of Object.entries(config.extraEnv ?? {}))
    argv.push('--env', `${key}=${value}`);
  argv.push(config.image, command, ...args);
  return argv;
}

export function createDockerSpawn(config: DockerExecutionConfig): t.LocalSpawn {
  validateDockerExecutionConfig(config);
  return (
    command: string,
    args: string[],
    options: SpawnOptions
  ): ChildProcessWithoutNullStreams =>
    spawn('docker', buildDockerArgs(config, command, args), {
      ...options,
      shell: false,
      stdio: ['pipe', 'pipe', 'pipe'],
    }) as ChildProcessWithoutNullStreams;
}

export const dockerExecutionCapabilities: DockerExecutionCapabilities = {
  cpu: true,
  memory: true,
  ephemeralDisk: true,
  networkModes: ['NONE', 'LOCAL_LAB', 'WEB'],
};

/** Ensure the concrete Docker backend is never broader than an action grant. */
export function assertDockerGrantCompatibility(
  grant: ExecutionGrant,
  config: DockerExecutionConfig
): void {
  const mode = config.networkMode ?? 'NONE';
  if (grant.networkMode != null && grant.networkMode !== mode) {
    throw new Error('EXECUTION_GRANT_BACKEND_MISMATCH');
  }
  if (
    grant.cpuCores != null &&
    config.cpuCores != null &&
    config.cpuCores > grant.cpuCores
  ) {
    throw new Error('EXECUTION_GRANT_CPU_LIMIT_EXCEEDED');
  }
  if (
    grant.memoryBytes != null &&
    config.memoryBytes != null &&
    config.memoryBytes > grant.memoryBytes
  ) {
    throw new Error('EXECUTION_GRANT_MEMORY_LIMIT_EXCEEDED');
  }
  if (
    grant.diskBytes != null &&
    config.diskBytes != null &&
    config.diskBytes > grant.diskBytes
  ) {
    throw new Error('EXECUTION_GRANT_DISK_LIMIT_EXCEEDED');
  }
  if (
    (grant.cpuCores != null && config.cpuCores == null) ||
    (grant.memoryBytes != null && config.memoryBytes == null) ||
    (grant.diskBytes != null && config.diskBytes == null)
  ) {
    throw new Error('EXECUTION_GRANT_LIMIT_UNENFORCED');
  }
}
