import type { ProgrammaticHookContext } from '@/types';
import type { PreToolUseHookInput } from './types';
import { executeHooks } from './executeHooks';

/** Invoke the native durable phase; this adapter owns no authorization policy. */
export async function revalidateToolEffect(
  required: boolean,
  context: ProgrammaticHookContext | undefined,
  call: Pick<
    PreToolUseHookInput,
    'toolName' | 'toolUseId' | 'toolInput' | 'stepId' | 'turn'
  >
): Promise<Record<string, unknown>> {
  if (!required) return call.toolInput;
  if (context == null) throw new Error('EFFECT_TIME_AUTHORITY_REQUIRED');
  const result = await executeHooks({
    phase: 'effect-time',
    authorityRequired: true,
    registry: context.registry,
    input: {
      hook_event_name: 'PreToolUse',
      runId: context.runId,
      threadId: context.threadId,
      agentId: context.agentId,
      executingAgentId: context.executingAgentId,
      ...call,
    },
    sessionId: context.runId,
    matchQuery: call.toolName,
  });
  if (result.decision !== 'allow') {
    throw new Error(result.reason ?? 'EFFECT_TIME_AUTHORITY_REQUIRED');
  }
  return result.updatedInput ?? call.toolInput;
}

export type ExecutionGrantStatus = 'ACTIVE' | 'REVOKED' | 'EXPIRED';

export interface ExecutionGrant {
  jobId: string;
  actionId: string;
  toolName: string;
  issuedAt: number;
  expiresAt: number;
  status?: ExecutionGrantStatus;
  cpuCores?: number;
  memoryBytes?: number;
  diskBytes?: number;
  networkMode?: 'NONE' | 'LOCAL_LAB' | 'ALLOWLIST' | 'WEB' | 'TOR_ALLOWLIST';
}

export interface ExecutionGrantResolutionInput {
  jobId: string;
  actionId: string;
  toolName: string;
  runId: string;
  threadId?: string;
  agentId?: string;
  executingAgentId?: string;
}

export type ExecutionGrantResolver = (
  input: ExecutionGrantResolutionInput
) => Promise<ExecutionGrant | undefined>;

export function validateExecutionGrant(
  grant: ExecutionGrant | undefined,
  input: ExecutionGrantResolutionInput,
  now: number = Date.now()
): void {
  if (grant == null) throw new Error('EXECUTION_GRANT_REQUIRED');
  if (grant.status === 'REVOKED') throw new Error('EXECUTION_GRANT_REVOKED');
  if (grant.status === 'EXPIRED') throw new Error('EXECUTION_GRANT_EXPIRED');
  if (grant.status !== 'ACTIVE')
    throw new Error('EXECUTION_GRANT_INVALID_STATUS');
  if (
    grant.status === 'EXPIRED' ||
    now < grant.issuedAt ||
    now >= grant.expiresAt
  ) {
    throw new Error('EXECUTION_GRANT_EXPIRED');
  }
  if (
    grant.jobId !== input.jobId ||
    grant.actionId !== input.actionId ||
    grant.toolName !== input.toolName
  ) {
    throw new Error('EXECUTION_GRANT_SCOPE_MISMATCH');
  }
  if (
    !Number.isFinite(grant.issuedAt) ||
    !Number.isFinite(grant.expiresAt) ||
    grant.expiresAt <= grant.issuedAt
  ) {
    throw new Error('EXECUTION_GRANT_INVALID');
  }
}
