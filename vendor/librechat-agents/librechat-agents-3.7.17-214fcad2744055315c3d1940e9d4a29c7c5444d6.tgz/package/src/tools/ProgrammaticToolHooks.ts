import type * as t from '@/types';
import { executeHooks } from '@/hooks';

/**
 * Run the host's `PreToolUse` hook chain for a single bridge call.
 * Returns the (possibly rewritten) input and a `denyReason` if any
 * matcher returned `decision: 'deny'` or `'ask'`. `'ask'` collapses
 * to deny because the bridge can't raise a LangGraph interrupt from
 * inside an HTTP handler — fail-closed matches the rest of the SDK
 * when HITL is unavailable.
 *
 * @internal Exported for tests so the deny / allow / updatedInput /
 *   ask branches can be exercised without standing up the full HTTP
 *   bridge.
 */
export async function applyPreToolUseHooksForBridge(
  hookContext: t.ProgrammaticHookContext,
  toolName: string,
  toolUseId: string,
  toolInput: Record<string, unknown>
): Promise<{ input: Record<string, unknown>; denyReason?: string }> {
  if (hookContext.registry == null) {
    return { input: toolInput };
  }
  const result = await executeHooks({
    registry: hookContext.registry,
    input: {
      hook_event_name: 'PreToolUse',
      runId: hookContext.runId,
      threadId: hookContext.threadId,
      agentId: hookContext.agentId,
      executingAgentId: hookContext.executingAgentId,
      toolName,
      toolInput,
      toolUseId,
      stepId: '',
      turn: 0,
    },
    sessionId: hookContext.runId,
    matchQuery: toolName,
  }).catch(() => undefined);
  if (result == null) {
    return { input: toolInput };
  }
  const nextInput =
    result.updatedInput != null
      ? (result.updatedInput as Record<string, unknown>)
      : toolInput;
  if (result.decision === 'deny' || result.decision === 'ask') {
    return {
      input: nextInput,
      denyReason:
        result.reason ??
        (result.decision === 'ask'
          ? `Tool "${toolName}" requires human approval; bridge cannot raise an interrupt — denying.`
          : `Tool "${toolName}" denied by PreToolUse hook.`),
    };
  }
  return { input: nextInput };
}
